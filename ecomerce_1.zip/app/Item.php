<?php


namespace App;


class Item
{
    public int $id;
    public float $price;
    public string $name;
    public string $slug;
    public int $qty;
    public string $image;
}
